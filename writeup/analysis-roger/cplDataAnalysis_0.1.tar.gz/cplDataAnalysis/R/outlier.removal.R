cbind.list <- function(l) {
  result <- c()
  for(i in 1:length(l)) {
    result <- cbind(result,l[[i]])
  }
  result
}


#create a z-score specific to the measure, for each condition and region (Crit)
z.score <- function(data,measure=data$RT,by=list(data$Cond,data$Region)) {
  means <- tapply(measure,by,mean)
  sds <- tapply(measure,by,sd)
  idx <- cbind.list(by)
  (measure - means[idx]) / sds[idx]
}


iqr.cutoff <- function(data,below=T,measure=data$RT,by=list(data$Cond,data$Region),a=3) {
  ranks <- tapply(measure,by,rank)
  l <- tapply(measure,by,length)
  medians <- tapply(measure,by,median)
  if(below) {
    quant.25 <- tapply(measure,by,quantile,probs=0.25)
    cutoff <- medians - a * (medians - quant.25)
  }
  else {
    quant.75 <- tapply(measure,by,quantile,probs=0.75)
    cutoff <- medians + a * (quant.75 + medians)
  }
  idx <- cbind.list(by)
  cutoff[idx]
}

iqr.passed <- function(data,measure=data$RT,by=list(data$Cond,data$Region),a=3) {
  below <- iqr.cutoff(data,below=T,measure,by,a)
  above <- iqr.cutoff(data,below=F,measure,by,a)
  (data$RT < above) & (data$RT > below)
}


remove.outliers <- function(data,measure=data$RT,by="Subj",cond.names=c("Cond"),method="Z.bycell",new.col.name=NULL,cutoff=3.0) {
  if(method=="Z.bycell") {
    z <- z.score(data,measure,by,cond.names)
    if(! is.null(new.col.name)) 
      data[[new.col.name]] <- z
    subset(data,abs(z) <=3.0)
  }
  else { # nothing else implemented yet
    data
  }
}
